package uniandes.dpoo.taller0.modelo;

/**
 * Esta enumeración sirve para indicar los posibles valores de género.
 * 
 * Los valores de la enumeración son: MASCULINO y FEMENINO
 */
public enum Genero
{
	MASCULINO, FEMENINO
}
